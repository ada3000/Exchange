﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Runtime.Caching;
using System.Threading.Tasks;
using System.Web.Http;

namespace TestResumable.Controllers
{
    public class UploadController : ApiController
    {
        public readonly long MaxFileSize = 50000000;
        public readonly TimeSpan FileLifetime = TimeSpan.FromSeconds(300);
        private const string CachePrifex = "UploadFileStore_";

        private void ReserveSpace(string id, long size)
        {
            if(size> MaxFileSize)
            {
                throw new ArgumentOutOfRangeException("MaxFileSize is " + MaxFileSize);
            }

            byte[] buffer = new byte[size];

            MemoryCache.Default.Add(CachePrifex + id, buffer, DateTimeOffset.Now.Add(FileLifetime));
        }

        private void UpdateChunk(string id, int chunkNumber, int chunkSize, byte[] data)
        {
            byte[] buffer = MemoryCache.Default.Get(CachePrifex + id) as byte[];
            if(buffer == null)
            {
                throw new ArgumentOutOfRangeException($"File {id} not found!");
            }

            int start = (chunkNumber - 1) * chunkSize;
            int end = start + data.Length;
            for(int i=start; i< end; i++)
            {
                buffer[i] = data[i - start];
            }
        }

        private byte[] GetFile(string id)
        {
            byte[] buffer = MemoryCache.Default.Get(CachePrifex + id) as byte[];
            if (buffer == null)
            {
                throw new ArgumentOutOfRangeException($"File {id} not found!");
            }

            return buffer;
        }


        [HttpGet, Route("api/upload")]
        public async Task<IHttpActionResult> CheckFile(
                int chunkNumber, //1
                int chunkSize, //1048576
                int currentChunkSize,// 86441
                long totalSize, //86441
                string type, //application/zip
                string identifier, //86441-resumablejs-110zip
                string fileName, //resumable.js-1.1.0.zip
                string relativePath, //resumable.js-1.1.0.zip
                int totalChunks// 1
            )
        {
            ReserveSpace(identifier, totalSize);

            return Ok();
        }

        [HttpPost, Route("api/upload")]
        public async Task<IHttpActionResult> StoreFile(
                int chunkNumber, //1
                int chunkSize, //1048576
                int currentChunkSize,// 86441
                long totalSize, //86441
                string type, //application/zip
                string identifier, //86441-resumablejs-110zip
                string fileName, //resumable.js-1.1.0.zip
                string relativePath, //resumable.js-1.1.0.zip
                int totalChunks// 1
            )
        {
            if (!Request.Content.IsMimeMultipartContent())
            {
                throw new HttpResponseException(HttpStatusCode.UnsupportedMediaType);
            }

            if (fileName == "resumable.js-1.1.0.zip")
            {
                throw new Exception("test error");
            }

            var provider = new MultipartMemoryStreamProvider();
            await Request.Content.ReadAsMultipartAsync(provider);
            foreach (var file in provider.Contents)
            {
                if (String.IsNullOrEmpty(file.Headers.ContentDisposition.FileName))
                {
                    continue;
                }

                var buffer = await file.ReadAsByteArrayAsync();

                UpdateChunk(identifier, chunkNumber, chunkSize, buffer);
            }

            return Ok();
        }
    }
}
